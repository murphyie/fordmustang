import ScrollKeyboardHero from './components/ScrollKeyboardHero';
import TransformationSection from './components/TransformationSection';
import FeaturesSection from './components/FeaturesSection';
import ImmersiveSection from './components/ImmersiveSection';
import CTASection from './components/CTASection';
import { useEffect } from 'react';

function App() {
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
  }, []);

  return (
    <div className="bg-black overflow-x-hidden">
      <ScrollKeyboardHero />
      <TransformationSection />
      <FeaturesSection />
      <ImmersiveSection />
      <CTASection />
    </div>
  );
}

export default App;
