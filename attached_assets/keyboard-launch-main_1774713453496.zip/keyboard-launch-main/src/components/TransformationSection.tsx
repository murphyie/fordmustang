import { useEffect, useRef, useState } from 'react';

export default function TransformationSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-screen bg-black py-32 px-6 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/3 right-1/4 w-[600px] h-[600px] bg-orange-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/3 left-1/4 w-[600px] h-[600px] bg-white/5 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className={`text-center mb-20 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-orange-300 bg-clip-text text-transparent">
            The Transformation
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Witness the evolution from everyday typing to gaming supremacy
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className={`transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-gray-800/20 to-gray-900/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all"></div>
              <div className="relative bg-gradient-to-br from-gray-900 to-black p-12 rounded-2xl border border-gray-800">
                <div className="flex flex-col gap-3 mb-6">
                  <div className="flex gap-2">
                    {[...Array(14)].map((_, i) => (
                      <div key={i} className="w-8 h-8 bg-gray-800 rounded border border-gray-700"></div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    {[...Array(14)].map((_, i) => (
                      <div key={i} className="w-8 h-8 bg-gray-800 rounded border border-gray-700"></div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    {[...Array(13)].map((_, i) => (
                      <div key={i} className="w-8 h-8 bg-gray-800 rounded border border-gray-700"></div>
                    ))}
                  </div>
                </div>
                <p className="text-gray-500 text-sm uppercase tracking-wider">Before</p>
                <p className="text-gray-400 mt-2">Standard Black Keyboard</p>
              </div>
            </div>
          </div>

          <div className={`transition-all duration-1000 delay-500 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-500/30 to-yellow-500/20 rounded-2xl blur-2xl group-hover:blur-3xl transition-all"></div>
              <div className="relative bg-gradient-to-br from-gray-900 to-black p-12 rounded-2xl border border-orange-500/30 shadow-2xl shadow-orange-500/20">
                <div className="flex flex-col gap-3 mb-6">
                  <div className="flex gap-2">
                    {[...Array(14)].map((_, i) => (
                      <div
                        key={i}
                        className="w-8 h-8 bg-gradient-to-br from-orange-500/40 to-gray-800 rounded border border-orange-400/50 shadow-lg shadow-orange-500/30 animate-pulse"
                        style={{ animationDelay: `${i * 0.05}s` }}
                      ></div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    {[...Array(14)].map((_, i) => (
                      <div
                        key={i}
                        className="w-8 h-8 bg-gradient-to-br from-orange-500/40 to-gray-800 rounded border border-orange-400/50 shadow-lg shadow-orange-500/30 animate-pulse"
                        style={{ animationDelay: `${i * 0.05 + 0.7}s` }}
                      ></div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    {[...Array(13)].map((_, i) => (
                      <div
                        key={i}
                        className="w-8 h-8 bg-gradient-to-br from-orange-500/40 to-gray-800 rounded border border-orange-400/50 shadow-lg shadow-orange-500/30 animate-pulse"
                        style={{ animationDelay: `${i * 0.05 + 1.4}s` }}
                      ></div>
                    ))}
                  </div>
                </div>
                <p className="text-orange-400 text-sm uppercase tracking-wider">After</p>
                <p className="text-white mt-2 font-medium">Gaming Performance Keyboard</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
