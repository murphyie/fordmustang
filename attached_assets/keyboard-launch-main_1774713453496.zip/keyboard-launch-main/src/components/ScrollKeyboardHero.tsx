import { useEffect, useRef, useState } from 'react';

export default function ScrollKeyboardHero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const scrollProgress = Math.max(0, Math.min(1, -rect.top / (rect.height - window.innerHeight)));
      setProgress(scrollProgress);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;

    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, rect.width, rect.height);

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const glowIntensity = progress;
    const orangeGlow = `rgba(255, 140, 50, ${glowIntensity * 0.4})`;
    const whiteGlow = `rgba(255, 255, 255, ${glowIntensity * 0.3})`;

    ctx.shadowBlur = 40 * progress;
    ctx.shadowColor = orangeGlow;

    const keyboardHeight = 140;
    const keySpacing = 6;
    const keySize = 28;

    const rows = [13, 13, 12, 10];
    let currentY = centerY - keyboardHeight / 2;

    rows.forEach((keysInRow) => {
      const rowWidth = keysInRow * (keySize + keySpacing) - keySpacing;
      let currentX = centerX - rowWidth / 2;

      for (let i = 0; i < keysInRow; i++) {
        const baseColor = progress < 0.5 ? '#1a1a1a' : '#2a2a2a';

        ctx.fillStyle = baseColor;
        ctx.fillRect(currentX, currentY, keySize, keySize);

        if (progress > 0.3) {
          const keyGlow = Math.random() * progress;
          const gradient = ctx.createRadialGradient(
            currentX + keySize / 2,
            currentY + keySize / 2,
            0,
            currentX + keySize / 2,
            currentY + keySize / 2,
            keySize
          );
          gradient.addColorStop(0, `rgba(255, 140, 50, ${keyGlow * 0.6})`);
          gradient.addColorStop(0.5, `rgba(255, 200, 100, ${keyGlow * 0.3})`);
          gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

          ctx.fillStyle = gradient;
          ctx.fillRect(currentX, currentY, keySize, keySize);
        }

        ctx.strokeStyle = progress > 0.5 ? `rgba(255, 140, 50, ${progress * 0.5})` : '#333';
        ctx.lineWidth = 1;
        ctx.strokeRect(currentX, currentY, keySize, keySize);

        currentX += keySize + keySpacing;
      }

      currentY += keySize + keySpacing;
    });

    if (progress > 0.7) {
      ctx.shadowBlur = 60;
      ctx.shadowColor = orangeGlow;

      const glowGradient = ctx.createRadialGradient(
        centerX, centerY, 0,
        centerX, centerY, 300
      );
      glowGradient.addColorStop(0, whiteGlow);
      glowGradient.addColorStop(0.5, orangeGlow);
      glowGradient.addColorStop(1, 'rgba(255, 140, 50, 0)');

      ctx.fillStyle = glowGradient;
      ctx.fillRect(centerX - 250, centerY - 150, 500, 300);
    }
  }, [progress]);

  return (
    <div ref={containerRef} className="relative h-[300vh]">
      <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden bg-black">
        <div className="absolute inset-0 bg-gradient-radial from-gray-900/20 via-black to-black"></div>

        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-400/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        </div>

        <div className="relative z-10 text-center">
          <div className="mb-8 opacity-0 animate-fade-in" style={{ animationDelay: '0.5s', animationFillMode: 'forwards' }}>
            <h1 className="text-7xl md:text-8xl font-bold mb-6 tracking-tight">
              <span className="bg-gradient-to-r from-white via-orange-200 to-orange-500 bg-clip-text text-transparent">
                Upgrade Your Experience
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-400 font-light tracking-wide">
              From standard to unstoppable — feel the evolution
            </p>
          </div>

          <canvas
            ref={canvasRef}
            className="w-full max-w-2xl mx-auto"
            style={{ width: '100%', height: '400px' }}
          />

          {progress < 0.1 && (
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce">
              <div className="flex flex-col items-center gap-2 text-gray-500">
                <span className="text-sm tracking-widest uppercase">Scroll to explore</span>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
