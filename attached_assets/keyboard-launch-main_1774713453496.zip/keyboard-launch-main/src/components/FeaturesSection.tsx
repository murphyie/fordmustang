import { Zap, Sparkles, Award, Gamepad2 } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

const features = [
  {
    icon: Zap,
    title: 'Lightning Response',
    description: 'Ultra-fast mechanical switches with 1ms response time for instant key actuation',
    gradient: 'from-orange-500 to-yellow-500',
  },
  {
    icon: Sparkles,
    title: 'Dynamic RGB Lighting',
    description: 'Customizable orange-white lighting effects that pulse with your gameplay',
    gradient: 'from-orange-400 to-white',
  },
  {
    icon: Award,
    title: 'Premium Build',
    description: 'Aircraft-grade aluminum frame with double-shot PBT keycaps for lasting durability',
    gradient: 'from-gray-300 to-white',
  },
  {
    icon: Gamepad2,
    title: 'Gaming Optimized',
    description: 'N-key rollover and anti-ghosting technology for flawless performance',
    gradient: 'from-orange-500 to-orange-300',
  },
];

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-screen bg-gradient-to-b from-black to-gray-950 py-32 px-6">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-orange-500/50 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className={`text-center mb-20 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-6xl md:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white via-orange-200 to-orange-500 bg-clip-text text-transparent">
              Engineered to Dominate
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Every detail crafted for the ultimate gaming advantage
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`transition-all duration-1000 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="group relative h-full">
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500`}></div>

                <div className="relative h-full bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-sm p-8 rounded-2xl border border-gray-800 group-hover:border-orange-500/30 transition-all duration-500">
                  <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${feature.gradient} mb-6 group-hover:scale-110 transition-transform duration-500`}>
                    <feature.icon className="w-8 h-8 text-black" strokeWidth={2} />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-orange-400 transition-colors">
                    {feature.title}
                  </h3>

                  <p className="text-gray-400 leading-relaxed">
                    {feature.description}
                  </p>

                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-white group-hover:w-full transition-all duration-700"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
