import { useEffect, useRef, useState } from 'react';

export default function ImmersiveSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;

      const rect = sectionRef.current.getBoundingClientRect();
      const sectionTop = rect.top;
      const sectionHeight = rect.height;
      const windowHeight = window.innerHeight;

      const progress = Math.max(0, Math.min(1, (windowHeight - sectionTop) / (windowHeight + sectionHeight / 2)));
      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-screen bg-black py-32 px-6 overflow-hidden">
      <div className="absolute inset-0">
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full transition-all duration-1000"
          style={{
            background: `radial-gradient(circle, rgba(255, 140, 50, ${scrollProgress * 0.3}) 0%, rgba(255, 200, 100, ${scrollProgress * 0.15}) 30%, transparent 70%)`,
            transform: `translate(-50%, -50%) scale(${0.5 + scrollProgress * 0.5})`,
          }}
        ></div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-6xl md:text-8xl font-bold mb-8 transition-all duration-1000"
            style={{
              opacity: scrollProgress,
              transform: `translateY(${(1 - scrollProgress) * 50}px)`,
            }}
          >
            <span className="bg-gradient-to-r from-orange-500 via-white to-orange-300 bg-clip-text text-transparent">
              Immerse Yourself
            </span>
          </h2>
          <p
            className="text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed transition-all duration-1000 delay-200"
            style={{
              opacity: scrollProgress,
              transform: `translateY(${(1 - scrollProgress) * 30}px)`,
            }}
          >
            Feel every keystroke. Experience unparalleled precision. Dominate with style.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-20">
          {[
            {
              label: 'Speed',
              value: '1ms',
              description: 'Response Time',
            },
            {
              label: 'Precision',
              value: '100%',
              description: 'Accuracy',
            },
            {
              label: 'Style',
              value: '∞',
              description: 'Customization',
            },
          ].map((stat, index) => (
            <div
              key={index}
              className="text-center transition-all duration-1000"
              style={{
                opacity: scrollProgress,
                transform: `translateY(${(1 - scrollProgress) * 40}px)`,
                transitionDelay: `${index * 100 + 400}ms`,
              }}
            >
              <div className="relative inline-block mb-4">
                <div className="absolute inset-0 bg-orange-500/20 blur-2xl rounded-full animate-pulse"></div>
                <div className="relative text-7xl md:text-8xl font-bold bg-gradient-to-b from-white to-orange-400 bg-clip-text text-transparent">
                  {stat.value}
                </div>
              </div>
              <div className="text-orange-400 text-sm uppercase tracking-widest mb-2">{stat.label}</div>
              <div className="text-gray-500 text-lg">{stat.description}</div>
            </div>
          ))}
        </div>

        <div
          className="mt-24 relative transition-all duration-1000"
          style={{
            opacity: scrollProgress,
            transform: `scale(${0.9 + scrollProgress * 0.1})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 via-white/10 to-orange-500/20 blur-3xl rounded-full"></div>
          <div className="relative bg-gradient-to-br from-gray-900/50 to-black/50 backdrop-blur-xl p-12 md:p-16 rounded-3xl border border-orange-500/20 shadow-2xl shadow-orange-500/10">
            <blockquote className="text-2xl md:text-3xl text-center text-gray-300 font-light leading-relaxed italic">
              "The keyboard doesn't just respond to you—it anticipates, adapts, and amplifies your every move."
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
